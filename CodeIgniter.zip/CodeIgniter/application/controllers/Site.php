<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('site_model');
    }
    public function index()
	{
        $message=$this->site_model->run_my_query();
        $array_info=array(
            'name'=>"Mohammed Soubani",
            'email'=>"alisoubani98@gmail.com",
            'message'=>$message

        );
		$this->load->view('home_page',$array_info);
        //echo $this->site_model->run_my_query();
	}
    public function pass_Ver()
    {
        // $array_info = array("name"=>"Mohammed Soubani","email"=>"alisoubani98@gmail.com","phone number"=>"0799254227");
        $array_info['name']="Mohammed Soubani";
        $array_info['email']="alisoubani98@gmail.com";
        
        $this->load->view('pass_veriable',$array_info);
    }
    public function about()
    {
        $this->load->view('site_about');
    }
    public function contact_info(){
     
        echo "<h1>This is contact us page</h1>";
    }
    public function service($number){
        echo "<h3>This is service number</h3>".$number;
    }
    public function two_argumants($num,$text)
    {
        echo '<h4>this is number you pass:</h4>'.$num;
        echo '<br>';
        echo '<h6>This text you pass:</h6>'.$text;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php $this->load->view('include/header');?>
</head>
<body>
<?php $this->load->view('site/site_index');?>
<?php $this->load->view('include/footer');?>
<?php echo 'developed by: '.$name ?><br>
<?php echo 'email:'.$email;?><br>
<?php echo 'message:'.$message;?>


</body>
</html>
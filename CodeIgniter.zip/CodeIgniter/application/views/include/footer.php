<footer>
    <p>all the code developed by the king of kings mohammed soubani</p>
</footer>
</body>
</html>
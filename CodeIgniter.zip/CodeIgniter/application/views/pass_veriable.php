<div>
    <h3>
        welcome to codeigniter 
    </h3>
    <p>
        Developed by :<?php  echo $name;?>
    </p>
    <p>
        Author name: <?php  echo $name;?>
        <br>
        Author email:<?php  echo $email;?>
    </p>

</div>
<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Site_model extends CI_Model{
    function run_my_query(){
        return "This message came from Site_model";
    }
}
?>